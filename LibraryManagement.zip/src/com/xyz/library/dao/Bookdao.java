package com.xyz.library.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.xyz.library.entity.Book;
import com.xyz.library.entity.GroupOfBooks;

public class Bookdao {
	private Connection con;

	public Bookdao(Connection con) {
		super();
		this.con = con;
	}

	public boolean setBookDetails(Book book) {
		String qry = "insert into book (referenceno,groupbookid) values(?,?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(qry);
			pstmt.setString(1, book.getBookserialNo());
			pstmt.setInt(2, book.getGroupofbookid());
			pstmt.execute();
			return true;

		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public boolean setGroupBookDetails(Book book) {
		String qry = "insert into groupofbook (Bookname,Author,yop,categoryid) values(?,?,?,?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(qry);
			pstmt.setString(1, book.getBookName());
			pstmt.setString(2, book.getAuthor());
			pstmt.setString(3, book.getYop());
			pstmt.setInt(4, book.getCategory());

			pstmt.execute();
			return true;

		} catch (Exception e) {
			e.printStackTrace();

		}

		return false;

	}

	public boolean deleteBooks(String bookreferenceid) {
		String qry="DELETE FROM book where referenceno=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(qry);
			pstmt.setString(1, bookreferenceid);
			int i=pstmt.executeUpdate();
			if(i==1)
			return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;

	}
	
	public boolean issueBook(Book book) {
		String qry="UPDATE book SET availability = ?, issueddate = ? , returndate=?, sid=? WHERE referenceno=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(qry);
			pstmt.setString(1, book.getAvailability());
			pstmt.setString(2, book.getIssueddate());
			pstmt.setString(3, book.getReturndate());
			pstmt.setInt(4, book.getStudentid());
			pstmt.setString(5, book.getBookserialNo());
			int i=pstmt.executeUpdate();
			System.out.println(i);
			if(i==1)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;

	}
	public String getReturnDate(String bookReferenceid) {
		String qry="Select returndate from book where referenceno=?";
		String returnDate=null;
		PreparedStatement pstmt = null;
		ResultSet resultSet=null;
		try {
			pstmt = con.prepareStatement(qry);
			pstmt.setString(1, bookReferenceid);
			resultSet=pstmt.executeQuery();
			if(resultSet.next()) {
		      returnDate=resultSet.getString("returndate");
				return returnDate;
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnDate;
	}
	
	public boolean updatereturnedbooks(Book book) {
		String qry="UPDATE book SET availability = ?, issueddate = ? , returndate=?, sid=? WHERE referenceno=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(qry);
			pstmt.setString(1, book.getAvailability());
			pstmt.setString(2, book.getIssueddate());
			pstmt.setString(3, book.getReturndate());
			pstmt.setInt(4, book.getStudentid());
			pstmt.setString(5, book.getBookserialNo());
			int i=pstmt.executeUpdate();
			if(i==1)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	
	public ArrayList<Book> getAllBook(String keyWord) {
		String qry="SELECT * FROM book INNER JOIN groupofbook ON book.groupbookid=groupofbook.id INNER JOIN student ON student.studentid=book.sid INNER JOIN category ON category.cid=groupofbook.categoryid";
		Statement stmt=null;
		ResultSet rs=null;
		ArrayList<Book> searchBookList=new ArrayList<>();
		try {
			stmt=con.createStatement();
			rs=stmt.executeQuery(qry);
			Book book;
			while(rs.next()) {
				String referenceNo=rs.getString("referenceno");
				String availability=rs.getString("availability");
				String issueDate=rs.getString("issueddate");
				String returnDate=rs.getString("returndate");
				int bookId=rs.getInt("id");
				String bookName=rs.getString("Bookname");
				String author=rs.getString("Author");
				String yop=rs.getString("yop");
				int studentId=rs.getInt("studentid"); 
				String studentName=rs.getString("sname");
				int categoryId=rs.getInt("cid");
				String categoryName=rs.getString("name");
				
				String total=referenceNo+" "+availability+" "+issueDate+" "+returnDate+" " +bookId+" "+
						bookName+" "+author+" "+yop+" "+studentId+" "+studentName+" "+categoryId+" "+categoryName;
				
				if(total.contains(keyWord)) {
					
					book=new Book(referenceNo, availability, issueDate, returnDate, studentId, studentName, bookId, bookName, author, yop, categoryId, categoryName);
					searchBookList.add(book);
				}
					
					
					
//					
//					System.out.println(referenceNo+" "+availability+" "+issueDate+" "+returnDate+" "+bookId+" "+
//						bookName+" "+author+" "+yop+" "+studentId+" "+studentName+" "+categoryId+" "+categoryName);
//					
				
				
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return searchBookList;
		
	}
	
	public ArrayList<Book> fetchcategoryIdAndName() {
		
		String qry="select * from category";
		Statement stmt=null;
		ResultSet rs=null;
		Book book;
		ArrayList<Book> categorylist=new ArrayList<>();
		try {
			stmt=con.createStatement();
			rs=stmt.executeQuery(qry);
			while(rs.next()) {
				
				int id=rs.getInt("cid");
				String categoryName=rs.getString("name");
				book=new Book(id, categoryName);
				categorylist.add(book);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return categorylist;
	}
	
public ArrayList<GroupOfBooks> fetchBookGroupDetails() {
		
		String qry="select * from groupofbook";
		Statement stmt=null;
		ResultSet rs=null;
		Book book;
		ArrayList<GroupOfBooks> groupOfBookList=new ArrayList<>();
		try {
			stmt=con.createStatement();
			rs=stmt.executeQuery(qry);
			while(rs.next()) {
				
				int id=rs.getInt("id");
				String bookName=rs.getString("Bookname");
				GroupOfBooks bookgroup=new GroupOfBooks(id, bookName);
				groupOfBookList.add(bookgroup);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return groupOfBookList;
	}
	
	public void updateName(String name,int oldBookId) {
		String qry="UPDATE groupofbook SET Bookname=? WHERE id=?";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Book book;
		try {
			pstmt=con.prepareStatement(qry);
			pstmt.setString(1, name);
			pstmt.setInt(2, oldBookId);
			pstmt.execute();
			System.out.println("data updated in bookdao");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void updateAuthor(String author,int oldBookId) {
		String qry="UPDATE groupofbook SET Author=? WHERE id=?";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Book book;
		try {
			pstmt=con.prepareStatement(qry);
			pstmt.setString(1, author);
			pstmt.setInt(2, oldBookId);
			pstmt.execute();
			System.out.println("data updated in bookdao");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void updateYop(String yop,int oldBookId) {
		String qry="UPDATE groupofbook SET yop=? WHERE id=?";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Book book;
		try {
			pstmt=con.prepareStatement(qry);
			pstmt.setString(1, yop);
			pstmt.setInt(2, oldBookId);
			pstmt.execute();
			System.out.println("data updated in bookdao");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public void updateCategory(int category,int oldBookId) {
		String qry="UPDATE groupofbook SET categoryid=? WHERE id=?";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Book book;
		try {
			pstmt=con.prepareStatement(qry);
			pstmt.setInt(1, category);
			pstmt.setInt(2, oldBookId);
			pstmt.execute();
			System.out.println("data updated in bookdao");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
