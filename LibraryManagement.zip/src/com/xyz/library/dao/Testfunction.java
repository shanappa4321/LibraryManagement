package com.xyz.library.dao;

import java.sql.Connection;

import com.xyz.library.entity.Admin;
import com.xyz.library.entity.Book;
import com.xyz.library.helper.DBConnectionProvider;

public class Testfunction {
	public static void main(String[] args) {
		Connection con=DBConnectionProvider.getConnection();
		Admin adminobj=new Admin("shouvik", "shouvik123");
		AdminDao admindao=new AdminDao(con);
		Admin admin=admindao.getAdminByEmailPassword(adminobj);
		System.out.println(admin);
		
	}
}
