package com.xyz.library.dao;

import java.sql.Connection;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.xyz.library.entity.Admin;
import com.xyz.library.entity.Book;
import com.xyz.library.entity.Librarian;
import com.xyz.library.helper.DBConnectionProvider;

public class TestingFunc {
	public static void main(String[] args) {
		Bookdao bookdao=new Bookdao(DBConnectionProvider.getConnection());
		bookdao.fetchBookId("java");


		
	}
}
