package com.xyz.library.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.xyz.library.entity.Librarian;

public class Librariandao {
	private Connection con;

	public Librariandao(Connection con) {
		super();
		this.con = con;
	}
	
	public Librarian getLibrarianByEmailPassword(Librarian librarian) {
		Librarian returnedlibrarian=null;
		String qry = "select * from librarian where username =? and password=?";
		ResultSet rs=null;
		
		try {
			
			PreparedStatement pstmt=con.prepareStatement(qry);
			
			pstmt.setString(1, librarian.getUserName());
			pstmt.setString(2, librarian.getPassword());
			rs=pstmt.executeQuery();
			if(rs.next()) {
				int id=rs.getInt("id");
				String name=rs.getString("name");
				returnedlibrarian=new Librarian(id, name, librarian.getUserName(), librarian.getPassword());
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		
		return returnedlibrarian;
		
		
		
		
		
	}
}
