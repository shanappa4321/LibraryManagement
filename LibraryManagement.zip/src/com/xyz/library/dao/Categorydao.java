package com.xyz.library.dao;

public class Categorydao {

}
