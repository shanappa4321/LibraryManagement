package com.xyz.library.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.xyz.library.entity.Admin;

public class AdminDao {
	private Connection con;

	public AdminDao(Connection con) {
		super();
		this.con = con;
	}
	
	public Admin getAdminByEmailPassword(Admin admin) {
		Admin returnedadmin=null;
		String qry = "select * from admin where username =? and password=?";
		ResultSet rs=null;
		
		try {
			PreparedStatement pstmt=con.prepareStatement(qry);
			
			pstmt.setString(1, admin.getUserName());
			pstmt.setString(2, admin.getPassword());
			rs=pstmt.executeQuery();
			if(rs.next()) {
				int id=rs.getInt("id");
				String name=rs.getString("name");
				returnedadmin=new Admin(id, name, admin.getUserName(), admin.getPassword());
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		
		return returnedadmin;
		
		
		
		
		
	}
}
