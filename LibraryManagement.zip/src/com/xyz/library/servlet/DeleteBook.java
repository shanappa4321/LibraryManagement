package com.xyz.library.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.xyz.library.dao.Bookdao;
import com.xyz.library.helper.DBConnectionProvider;

/**
 * Servlet implementation class DeleteBook
 */
//@WebServlet("/DeleteBook")
public class DeleteBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String bookreferenceid=request.getParameter("bookreferenceid");
			System.out.println(bookreferenceid);
			HttpSession session=request.getSession();
			Bookdao bookdao=new Bookdao(DBConnectionProvider.getConnection());
			boolean isBookDeleted=bookdao.deleteBooks(bookreferenceid);	
			if(isBookDeleted) {
				session.setAttribute("msg", "book deleted successfully");
				session.setAttribute("colour", "green");
				response.sendRedirect("profile.jsp");
				
			}
			else {
				
				session.setAttribute("msg", "Can't delete book please check reference id");
				session.setAttribute("colour", "red");
				response.sendRedirect("profile.jsp");
			}
				
	
	}

}
