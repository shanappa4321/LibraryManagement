package com.xyz.library.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.xyz.library.dao.Bookdao;
import com.xyz.library.entity.Book;
import com.xyz.library.helper.DBConnectionProvider;

/**
 * Servlet implementation class Acceptreturn
 */
//@WebServlet("/Acceptreturn")
public class Acceptreturn extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String bookReferenceId=request.getParameter("bookreferenceid");
		System.out.println(bookReferenceId);
		Bookdao bookdao=new Bookdao(DBConnectionProvider.getConnection());
		String returnDate=bookdao.getReturnDate(bookReferenceId);
		if(returnDate==null)
		{
			session.setAttribute("msg", "book is not present");
			session.setAttribute("colour", "red");
			response.sendRedirect("profile.jsp");
		}
		else if(returnDate.equals("NA")) {
			session.setAttribute("msg", "Book is not issued");
			session.setAttribute("colour", "red");
			response.sendRedirect("profile.jsp");
			
		}
		
		else {
			String availabilityUpdated="available";
			String issueDateUpdated = "NA";
			String returnDateUpdated="NA";
			int studentId=0;
			Book book=new Book(bookReferenceId, availabilityUpdated, issueDateUpdated, returnDateUpdated, studentId);
			bookdao.updatereturnedbooks(book);
			
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			String lateReturnDate = simpleDateFormat.format(new Date());
			Date dateObj1;
			int finePerDay=5;
			int fine=0;
			try {
				dateObj1 = simpleDateFormat.parse(returnDate);
				Date dateObj2 = simpleDateFormat.parse(lateReturnDate);

				long diff = dateObj2.getTime() - dateObj1.getTime();

				int diffDays = (int) (diff / (24 * 60 * 60 * 1000));
				System.out.println("difference between days: " + diffDays);
				if(diffDays>0)
				fine=diffDays*finePerDay;
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			String message="you have been fined "+fine+" rs";
			
			if(fine!=0) {
				session.setAttribute("msg", message);
				session.setAttribute("colour", "green");
				response.sendRedirect("profile.jsp");
			}
			else {
				session.setAttribute("msg", "book returned");
				session.setAttribute("colour", "green");
				response.sendRedirect("profile.jsp");
			}
			
		}

//		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
//		String returnDate = simpleDateFormat.format(new Date());
		
	}

}
