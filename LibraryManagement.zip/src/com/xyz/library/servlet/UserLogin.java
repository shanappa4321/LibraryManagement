package com.xyz.library.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.xyz.library.dao.AdminDao;
import com.xyz.library.dao.Bookdao;
import com.xyz.library.dao.Librariandao;
import com.xyz.library.entity.Admin;
import com.xyz.library.entity.Book;
import com.xyz.library.entity.GroupOfBooks;
import com.xyz.library.entity.Librarian;
import com.xyz.library.helper.DBConnectionProvider;

/**
 * Servlet implementation class UserLogin
 */
//@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type=request.getParameter("user");
		String userName=request.getParameter("username");
		String password=request.getParameter("password");
		Connection con=DBConnectionProvider.getConnection();
		HttpSession session=request.getSession();
		Bookdao bookdao=new Bookdao(DBConnectionProvider.getConnection());
		ArrayList<Book> categorylist=bookdao.fetchcategoryIdAndName();
		ArrayList<GroupOfBooks> groupBookList=bookdao.fetchBookGroupDetails();
		
		if(type.equals("admin")) {
			Admin adminobj=new Admin(userName, password);
			AdminDao admindao=new AdminDao(con);
			Admin admin=admindao.getAdminByEmailPassword(adminobj);
			if(admin!=null) {
			session.setAttribute("user", admin);
			session.setAttribute("bookcategory", categorylist);
			session.setAttribute("groupBookList", groupBookList);
			response.sendRedirect("profile.jsp");
			}
			if(admin==null)
				response.sendRedirect("error.html");
		}
			
		
		else {
			Librarian librarianobj=new Librarian(userName, password);
			Librariandao librariandao=new Librariandao(con);
			Librarian librarian=librariandao.getLibrarianByEmailPassword(librarianobj);
			
			if(librarian!=null) {
			session.setAttribute("user", librarian);
			response.sendRedirect("profile.jsp");
			}
			if(librarian==null)
				response.sendRedirect("error.html");
		}
			
		

	}

}
