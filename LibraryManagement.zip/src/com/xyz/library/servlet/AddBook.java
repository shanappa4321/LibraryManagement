package com.xyz.library.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.xyz.library.dao.Bookdao;
import com.xyz.library.entity.Book;
import com.xyz.library.helper.DBConnectionProvider;

/**
 * Servlet implementation class AddBook
 */
//@WebServlet("/AddBook")
public class AddBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String bookreferenceid=request.getParameter("bookreferenceno");
		System.out.println(bookreferenceid);
		int bookgroupid=Integer.parseInt(request.getParameter("bookgroupid"));
		Book book=new Book(bookreferenceid, bookgroupid);
		
		Bookdao bookdao=new Bookdao(DBConnectionProvider.getConnection());
		boolean isBookStored=bookdao.setBookDetails(book);
		HttpSession session=request.getSession();
		if(isBookStored) {
			
			session.setAttribute("msg", "book successfully added");
			session.setAttribute("colour", "green");
			response.sendRedirect("profile.jsp");
		}
		
		else {
			
			session.setAttribute("msg", "Can't add book please check the field again");
			session.setAttribute("colour", "red");
			response.sendRedirect("profile.jsp");
			
		}
		
	}
	


}
