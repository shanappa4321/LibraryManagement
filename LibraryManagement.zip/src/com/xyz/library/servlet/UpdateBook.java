package com.xyz.library.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xyz.library.dao.Bookdao;
import com.xyz.library.helper.DBConnectionProvider;

/**
 * Servlet implementation class UpdateBook
 */
//@WebServlet("/UpdateBook")
public class UpdateBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int oldBookId=Integer.parseInt(request.getParameter("bookgroupname"));
		String bookName=request.getParameter("newbookname");
		String newAuthorname=request.getParameter("authorname");
		String newYop=request.getParameter("yop");
		int newCategory=Integer.parseInt(request.getParameter("category"));
		System.out.println("newcategory" +newCategory);
		Bookdao bookdao=new Bookdao(DBConnectionProvider.getConnection());
		System.out.println("newAuthorname is"+newAuthorname);
		System.out.println(bookName);
//		int groupBookId=bookdao.fetchBookId(oldBookName);
		
		if(bookName!="") {
			
			bookdao.updateName(bookName, oldBookId);
		}
		
		if(newAuthorname!="") {
			
			bookdao.updateAuthor(newAuthorname, oldBookId);
		}
		
		if(newYop!="") {
			bookdao.updateYop(newYop, oldBookId);
			
		}
		
		if(newCategory!=0) {
			bookdao.updateCategory(newCategory, oldBookId);
		}

	}

}
