package com.xyz.library.servlet;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.xyz.library.dao.Bookdao;
import com.xyz.library.entity.Book;
import com.xyz.library.helper.DBConnectionProvider;

/**
 * Servlet implementation class AddBookGroup
 */
//@WebServlet("/AddBookGroup")
public class AddBookGroup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String bookName=request.getParameter("bookname");
		String author=request.getParameter("author");
		String yop=request.getParameter("yop");
		int category=Integer.parseInt(request.getParameter("category"));
		HttpSession session=request.getSession();
		
	Book book=new Book(bookName, author, yop, category);
	Bookdao bookdao=new Bookdao(DBConnectionProvider.getConnection());
	boolean isBookGroupStored=bookdao.setGroupBookDetails(book);
		if(isBookGroupStored) {
			session.setAttribute("msg", "book group successfully added");
			session.setAttribute("colour", "green");
			response.sendRedirect("profile.jsp");
		}
		else {
			
			session.setAttribute("msg", "Can't add book group please check the field again");
			session.setAttribute("colour", "red");
			response.sendRedirect("profile.jsp");
			
		}
			
		
	}

}
