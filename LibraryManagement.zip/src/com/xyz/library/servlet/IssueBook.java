package com.xyz.library.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.xyz.library.dao.Bookdao;
import com.xyz.library.entity.Book;
import com.xyz.library.helper.DBConnectionProvider;

/**
 * Servlet implementation class IssueBook
 */
//@WebServlet("/IssueBook")
public class IssueBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String bookReferenceId=request.getParameter("bookreferenceid");
		Bookdao bookdao=new Bookdao(DBConnectionProvider.getConnection());
		String returnDate=bookdao.getReturnDate(bookReferenceId);
		
		if(!returnDate.equals("NA"))
		{
			session.setAttribute("msg", "book has already been issued");
			session.setAttribute("colour", "red");
			response.sendRedirect("profile.jsp");
		}
		
		else {
		int studentId=Integer.parseInt(request.getParameter("studentid"));
		String availability="not available";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
		String issueDate = simpleDateFormat.format(new Date());
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Using today's date
		c.add(Calendar.DATE, 5); // Adding 5 days
		String returndate = simpleDateFormat.format(c.getTime());
		Book book=new Book(bookReferenceId,availability, issueDate, returndate, studentId);
		boolean isBookissued=bookdao.issueBook(book);
			if(isBookissued) {
				session.setAttribute("msg", "book issued successfully");
				session.setAttribute("colour", "green");
				response.sendRedirect("profile.jsp");
				
			}
			else {
				
				session.setAttribute("msg", "Can't issue book please check the field again");
				session.setAttribute("colour", "red");
				response.sendRedirect("profile.jsp");
				
			}
		}
	}

}
