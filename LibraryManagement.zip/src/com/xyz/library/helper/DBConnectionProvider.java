package com.xyz.library.helper;

import java.sql.DriverManager;

import com.mysql.jdbc.Connection;

public class DBConnectionProvider {

	private static Connection con;

	public static Connection getConnection() {


			try {
				System.out.println("loading driver");
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("driver loaded");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","root");
				System.out.println(con);

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

			return con;
		

	}
}