package com.xyz.library.entity;

public interface User {
	 
	public int getId();
	public void setId(int id);
	public String getName();
	public void setName(String name) ;

	public String getUserName() ;

	public void setUserName(String userName);
	public String getPassword();

	public void setPassword(String password);

	
}
