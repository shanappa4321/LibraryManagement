package com.xyz.library.entity;

public class GroupOfSameBook {
   int id;
   String name;
   String author;
   String yearOfPublication;
}
