package com.xyz.library.entity;

public class Book {
	String bookserialNo;
	String availability;
	String issueddate;
	String returndate;
	int studentid;
	String studentName;
	int groupofbookid;
	String bookName;
	String author;
	String yop;
	int categoryId;
	String categoryName;
	
	
	



	public Book(int categoryId, String categoryName) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}

	public Book(String bookserialNo, String availability, String issueddate, String returndate, int studentid,
			String studentName, int groupofbookid, String bookName, String author, String yop, int categoryId,
			String categoryName) {
		super();
		this.bookserialNo = bookserialNo;
		this.availability = availability;
		this.issueddate = issueddate;
		this.returndate = returndate;
		this.studentid = studentid;
		this.studentName = studentName;
		this.groupofbookid = groupofbookid;
		this.bookName = bookName;
		this.author = author;
		this.yop = yop;
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}

	public Book(String bookserialNo, int groupofbookid, String bookName, String availability, String author, String yop,
			int category, String issueddate, String returndate,  int studentid) {
		super();
		this.bookserialNo = bookserialNo;
		this.groupofbookid = groupofbookid;
		this.bookName = bookName;
		this.availability = availability;
		this.author = author;
		this.yop = yop;
		this.categoryId = category;
		this.issueddate = issueddate;
		this.returndate = returndate;
		
		this.studentid = studentid;
	}
	
	public Book(String bookName, String author, String yop, int category) {
		super();
		this.bookName = bookName;
		this.author = author;
		this.yop = yop;
		this.categoryId = category;
	}



	public Book(String bookserialNo, String availability, String issueddate, String returndate, int studentid) {
		super();
		this.bookserialNo = bookserialNo;
		this.availability = availability;
		this.issueddate = issueddate;
		this.returndate = returndate;
		this.studentid = studentid;
	}

	public Book(String bookserialNo, int groupofbookid) {
		super();
		this.bookserialNo = bookserialNo;
		this.groupofbookid = groupofbookid;
	}
	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getBookserialNo() {
		return bookserialNo;
	}
	public void setBookserialNo(String bookserialNo) {
		this.bookserialNo = bookserialNo;
	}
	public int getGroupofbookid() {
		return groupofbookid;
	}
	public void setGroupofbookid(int groupofbookid) {
		this.groupofbookid = groupofbookid;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getYop() {
		return yop;
	}
	public void setYop(String yop) {
		this.yop = yop;
	}
	public int getCategory() {
		return categoryId;
	}
	public void setCategory(int category) {
		this.categoryId = category;
	}
	public String getIssueddate() {
		return issueddate;
	}
	public void setIssueddate(String issueddate) {
		this.issueddate = issueddate;
	}
	public String getReturndate() {
		return returndate;
	}
	public void setReturndate(String returndate) {
		this.returndate = returndate;
	}
	
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	
	
}
